# api-arduino
API de Aquisição de Dados com Arduino - adaptado possibilitando inserção de dados em Nuvem
